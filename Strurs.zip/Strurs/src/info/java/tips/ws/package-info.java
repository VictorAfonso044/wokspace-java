@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.example.org/User", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package info.java.tips.ws;
