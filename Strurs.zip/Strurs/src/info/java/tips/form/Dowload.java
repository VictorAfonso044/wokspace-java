package info.java.tips.form;

import org.apache.struts.action.ActionForm;

public class Dowload extends ActionForm {

}
