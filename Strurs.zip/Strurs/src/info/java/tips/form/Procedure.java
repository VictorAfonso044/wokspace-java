package info.java.tips.form;

import org.apache.struts.action.ActionForm;

import lombok.Data;
@Data
public class Procedure extends ActionForm{
	
	private Integer numcampos;

}
