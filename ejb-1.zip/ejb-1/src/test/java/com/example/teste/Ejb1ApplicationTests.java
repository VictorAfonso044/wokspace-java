package com.example.teste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejb1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
