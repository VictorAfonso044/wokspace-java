package com.example.teste.service;

import org.springframework.stereotype.Service;

import com.example.teste.models.Cadastro;
import com.example.teste.user.GetUserRequest;

@Service
public class XmlService {
	
	public Cadastro cadastrar(GetUserRequest request) {
		Cadastro cadastro = new Cadastro();
		cadastro.setNomebeneficiario(request.getNomebeneficiario());
		cadastro.setIdbeneficiario(request.getIdbeneficiario());
		cadastro.setIdprontuario(request.getIdprontuario());
		cadastro.setNumcarteira(request.getNumcarteira());
		cadastro.setDatanascimento(request.getDatanascimento());
		cadastro.setDatainclusao(request.getDatainclusao());
		return cadastro;
	}

}
