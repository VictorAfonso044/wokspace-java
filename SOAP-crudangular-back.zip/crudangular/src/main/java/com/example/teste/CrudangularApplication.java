package com.example.teste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudangularApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudangularApplication.class, args);
	}

}
